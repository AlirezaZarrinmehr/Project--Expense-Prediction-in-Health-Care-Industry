# Load R packages
#install.packages("shinythemes")
#install.packages("shiny")
#install.packages("shinyWidgets")
#install.packages("shinythemes")
library(shiny)
library(shinyWidgets)
library(shinythemes)
library(tidyverse)
library(imputeTS)

df <- "https://intro-datascience.s3.us-east-2.amazonaws.com/HMO_data.csv"
File1 <- read_csv(df)
File1$bmi <- na_interpolation(File1$bmi)
File1$hypertension <- na_interpolation(File1$hypertension)

File1$expensive<- as.factor(File1$cost >= 5000)

library(kernlab)
library(caret)
library(ggplot2)
library(maps)
library(mapproj)
library(dplyr)
set.seed(111)
trainList <- createDataPartition(y=File1$expensive,p=.70,list=FALSE)
trainset <- File1[trainList, ]
testSet <- File1[-trainList, ]

svmFile1 <- ksvm(expensive ~age+bmi+smoker+hypertension+exercise+yearly_physical+education_level,data=trainset, C=5, cross=3, prob.model=TRUE)
svmFile1
svmFile2 <- predict(svmFile1,testSet)

File1$region <- tolower(File1$location)
file2 <- File1 %>% filter(File1$cost<40000)
us <- map_data("state")
mapandfile <- merge(file2,us,by="region")
mapandfile <- mapandfile %>% arrange(order)


library(shiny)
library(shinythemes)
library(shinyWidgets)
x<-data.frame('box_plot','Bar_graph','Scatter_plot')
ui <- fluidPage(theme = shinytheme("cyborg"),
                navbarPage(

                  "Medical Expenses",
                  tabPanel("Data",
                           sidebarPanel(
                             tags$h3("Input:"),
                             fileInput("file1", "Choose CSV File test data set", accept=c('text/csv', 
                                                                                          'text/comma-separated-values,text/plain','.csv')),
                             fileInput("file2", "Choose CSV File test validation set", accept=c('text/csv', 
                                                                                                'text/comma-separated-values,text/plain','.csv'))
                             
                           ), 
                           mainPanel(
                             h1("Test Data "),
                             tableOutput("dataT"),
                             
                           ) 
                  ), 
                  tabPanel("Confusion Matrix", verbatimTextOutput("con")
                  ),
                  
                  tabPanel("Result",verbatimTextOutput("Res")),
                  tabPanel("Sensitivity",verbatimTextOutput("sen")),
                  tabPanel("Exploratory Analysis",
                           sidebarLayout(
                             
                             
                             sidebarPanel(
                               
                             
                               radioButtons("dist", "Type of Graph:",
                                            c("Bar Graph" = "Bar",
                                              "Scatter Plot" = "Sca",
                                              "Box Plot" = "Box")
                                            
                               ),
                               
                             ),
                             mainPanel(
                               
                               
                               tabsetPanel(type = "tabs",
                                           tabPanel("Location",plotOutput("Loc")),
                                           tabPanel("Smoker", plotOutput("smo")),
                                           tabPanel("Hypertension", plotOutput("st")),
                                           tabPanel("Exercise", plotOutput("ex")),
                                           tabPanel("Gender", plotOutput("gen")),
                                           tabPanel("Married", plotOutput("mar")),
                                           tabPanel("Education Level", plotOutput("edu"))
                                           
                               )
                             )
                           )
                  ),
                  
                  tabPanel("Maps",plotOutput("map"))
                  
                )
) 

server <- function(input, output) {
  
  
  mydata <- reactive({
    file <- input$file1
    ext <- tools::file_ext(file$datapath)
    
    req(file)
    validate(need(ext == "csv", "Please upload a csv file"))
    
    read.csv(file$datapath)
  })
  
  mydata2 <- reactive({
    file <- input$file2
    ext <- tools::file_ext(file$datapath)
    req(file)
    validate(need(ext == "csv", "Please upload a csv file"))
    read.csv(file$datapath)
  })
  
  output$Res <- renderPrint({
    sol <- predict(svmFile1,mydata())
    sol
  })
  
  output$con <- renderPrint({
    confusionMatrix(svmFile2,testSet$expensive)
  })
  output$sen <- renderPrint({
    sol <- predict(svmFile1,mydata())
    act <- mydata2()$expensive
    con <- table(sol,act)
    sensitivity(con)
  })
  output$map<-renderPlot({
    map2 <- ggplot(mapandfile, aes(map_id=location)) + aes(x=long, y=lat, group=group)+
      geom_polygon(aes(fill=cost))+scale_fill_viridis_c(option="D")+
      coord_fixed(ratio = 1.5) +
      scale_y_continuous(expand = c(0,0))
    map2
  })
  output$dataT <- renderTable({
    mydata()
  })
  
  
  d <- function(type){
    dist <- switch(input$dist,
                   Bar= geom_bar(stat="identity"),
                   Sca = geom_jitter(),
                   Box = geom_boxplot())
  }
  
  output$Loc<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=location,y=cost)+d()
    h})
  output$smo<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=smoker,y=cost)+d()
    h})
  output$edu<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=education_level,y=cost)+d()
    h})
  output$mar<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=married,y=cost)+d()
    h})
  output$gen<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=gender,y=cost)+d()
    h})
  output$ex<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=exercise,y=cost)+d()
    h})
  output$st<-renderPlot({
    dist<-input$dist
    h<-ggplot(File1)+aes(x=hypertension,y=cost)+d()
    h})
  
}

shinyApp(ui = ui, server = server)